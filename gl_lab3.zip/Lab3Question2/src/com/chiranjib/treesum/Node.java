package com.chiranjib.treesum;

 class Node {
	int nodeData;
	Node leftNode, rightNode;

	Node(int data) { 
		nodeData = data;
	leftNode = rightNode = null;
	}
}